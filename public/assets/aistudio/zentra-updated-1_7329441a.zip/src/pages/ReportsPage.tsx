import React, { useState, useEffect, useMemo } from 'react';
import {
  FileText,
  Download,
  Printer,
  Archive,
  Server,
  ShieldCheck,
  CheckCircle2,
  XCircle,
  HelpCircle,
  RotateCw,
  Search,
  Filter,
  Eye,
  Terminal,
  ExternalLink,
  Layers,
  ChevronRight,
  Sparkles,
  Cpu,
} from 'lucide-react';
import jsPDF from 'jspdf';
import JSZip from 'jszip';
import { Card } from '../components/common/Card';
import { Modal } from '../components/common/Modal';
import { SeverityBadge } from '../components/common/Badge';
import {
  NetworkDevice,
  DeviceFrameworkEvaluation,
  SecurityFramework,
  ControlEvaluationResult,
} from '../types';
import { apiService } from '../services/api';
import { useToast } from '../context/ToastContext';
import { useAuth } from '../context/AuthContext';

export function ReportsPage({ onSelectFinding }: { onSelectFinding?: (id: string) => void }) {
  const [devices, setDevices] = useState<NetworkDevice[]>([]);
  const [evaluations, setEvaluations] = useState<DeviceFrameworkEvaluation[]>([]);
  const [frameworks, setFrameworks] = useState<SecurityFramework[]>([]);
  const [loading, setLoading] = useState(true);

  // Per-device generating state
  const [generatingIds, setGeneratingIds] = useState<Record<string, boolean>>({});

  // Bulk ZIP export state
  const [isBulkExporting, setIsBulkExporting] = useState(false);
  const [bulkProgress, setBulkProgress] = useState<{ current: number; total: number; hostname: string } | null>(null);

  // Preview Modal
  const [previewDevice, setPreviewDevice] = useState<NetworkDevice | null>(null);
  const [previewRemediations, setPreviewRemediations] = useState<Array<{ controlId: string; field: string; cliCommands: string }>>([]);
  const [loadingPreview, setLoadingPreview] = useState(false);

  // Filters
  const [search, setSearch] = useState('');
  const [vendorFilter, setVendorFilter] = useState('ALL');

  const { showToast } = useToast();
  const { user } = useAuth();

  const loadData = async () => {
    try {
      setLoading(true);
      const [devList, evalList, fwList] = await Promise.all([
        apiService.getDevices(),
        apiService.getComplianceEvaluations(),
        apiService.getComplianceFrameworks(),
      ]);
      setDevices(devList);
      setEvaluations(evalList);
      setFrameworks(fwList);
    } catch (err: any) {
      showToast('Error Loading Audit Data', err.message, 'error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleLoadSampleDevices = async () => {
    try {
      setLoading(true);
      const res = await apiService.loadSampleDevices();
      setDevices(res.devices);
      const freshEvals = await apiService.getComplianceEvaluations();
      setEvaluations(freshEvals);
      showToast('Sample Fleet Loaded', res.message, 'success');
    } catch (err: any) {
      showToast('Failed to load sample fleet', err.message, 'error');
    } finally {
      setLoading(false);
    }
  };

  // Helper to compile a PDF for a device
  const buildDevicePdf = async (device: NetworkDevice): Promise<{ doc: jsPDF; filename: string }> => {
    // 1. Gather all framework evaluations for this device
    let devEvals = evaluations.filter((e) => e.deviceId === device.id);
    if (devEvals.length === 0) {
      const evalRes = await apiService.evaluateCompliance(undefined, [device.id]);
      devEvals = evalRes.evaluations;
    }

    // 2. Extract failed controls
    const failedControls: ControlEvaluationResult[] = [];
    devEvals.forEach((ev) => {
      ev.controlResults.forEach((ctrl) => {
        if (ctrl.status === 'FAIL') {
          // Avoid duplicate control ID across frameworks if identical
          if (!failedControls.some((fc) => fc.controlId === ctrl.controlId)) {
            failedControls.push(ctrl);
          }
        }
      });
    });

    // 3. Request Gemini to adapt vendor-specific CLI remediation
    let cliRemediations: Array<{ controlId: string; field: string; cliCommands: string }> = [];
    try {
      if (failedControls.length > 0) {
        const res = await apiService.getVendorCliRemediations({
          vendor: device.detectedVendor,
          model: device.model,
          hostname: device.hostname,
          controls: failedControls.map((fc) => ({
            controlId: fc.controlId,
            title: fc.title,
            field: fc.field,
            expectedValue: fc.expectedValue,
            actualValue: fc.actualValue,
            remediation: fc.remediation,
          })),
        });
        cliRemediations = res.remediations;
      }
    } catch (err) {
      console.warn('CLI remediation generation fallback:', err);
    }

    // 4. Create jsPDF document
    const doc = new jsPDF({
      orientation: 'portrait',
      unit: 'mm',
      format: 'a4',
    });

    const pageWidth = doc.internal.pageSize.getWidth();
    const pageHeight = doc.internal.pageSize.getHeight();
    const margin = 14;
    let y = margin;

    // Helper: Add new page if content exceeds height
    const checkPageBreak = (neededHeight: number) => {
      if (y + neededHeight > pageHeight - 18) {
        doc.addPage();
        y = margin + 8;
        renderPageHeaderSmall();
      }
    };

    // Small running header on subsequent pages
    const renderPageHeaderSmall = () => {
      doc.setFillColor(15, 23, 42); // slate-900
      doc.rect(0, 0, pageWidth, 12, 'F');
      doc.setTextColor(6, 182, 212); // cyan-500
      doc.setFontSize(8);
      doc.setFont('helvetica', 'bold');
      doc.text(`ZENTRA COMPLIANCE REPORT: ${device.hostname || device.filename}`, margin, 8);
      doc.setTextColor(148, 163, 184); // slate-400
      doc.text(`Vendor: ${device.detectedVendor}`, pageWidth - margin - 50, 8);
      y = 18;
    };

    // Header Banner
    doc.setFillColor(15, 23, 42); // slate-900
    doc.rect(0, 0, pageWidth, 36, 'F');

    doc.setTextColor(6, 182, 212); // cyan-400
    doc.setFontSize(18);
    doc.setFont('helvetica', 'bold');
    doc.text('ZENTRA NETWORK SECURITY AUDIT REPORT', margin, 14);

    doc.setTextColor(226, 232, 240); // slate-200
    doc.setFontSize(9);
    doc.setFont('helvetica', 'normal');
    doc.text('Device Security Baseline & Multi-Framework Configuration Compliance Certificate', margin, 21);

    doc.setTextColor(148, 163, 184); // slate-400
    doc.setFontSize(8);
    doc.text(`Generated: ${new Date().toUTCString()}  |  Engine: ZENTRA Compliance Kernel v3.0`, margin, 28);

    y = 44;

    // Device Identification Card
    doc.setFillColor(248, 250, 252); // slate-50
    doc.setDrawColor(203, 213, 225); // slate-300
    doc.roundedRect(margin, y, pageWidth - margin * 2, 38, 2, 2, 'FD');

    doc.setTextColor(15, 23, 42); // slate-900
    doc.setFontSize(12);
    doc.setFont('helvetica', 'bold');
    doc.text('Device Identification & Hardware Inventory', margin + 4, y + 7);

    doc.setFontSize(9);
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(51, 65, 85);

    // Left Column
    doc.setFont('helvetica', 'bold');
    doc.text('Hostname:', margin + 4, y + 16);
    doc.setFont('helvetica', 'normal');
    doc.text(device.hostname || 'Unassigned / Not Detected', margin + 28, y + 16);

    doc.setFont('helvetica', 'bold');
    doc.text('Vendor / OS:', margin + 4, y + 23);
    doc.setFont('helvetica', 'normal');
    doc.text(`${device.detectedVendor} (${device.vendorGuessMethod.toUpperCase()} ${device.vendorConfidence}%)`, margin + 28, y + 23);

    doc.setFont('helvetica', 'bold');
    doc.text('Model:', margin + 4, y + 30);
    doc.setFont('helvetica', 'normal');
    doc.text(device.model || 'General Network Appliance', margin + 28, y + 30);

    // Right Column
    doc.setFont('helvetica', 'bold');
    doc.text('Serial Number:', margin + 105, y + 16);
    doc.setFont('helvetica', 'normal');
    doc.text(device.serialNumber || 'SN-UNKNOWN', margin + 132, y + 16);

    doc.setFont('helvetica', 'bold');
    doc.text('Config File:', margin + 105, y + 23);
    doc.setFont('helvetica', 'normal');
    doc.text(`${device.filename} (${device.lineCount} lines, ${Math.round(device.byteSize / 1024)} KB)`, margin + 132, y + 23);

    doc.setFont('helvetica', 'bold');
    doc.text('Ingested At:', margin + 105, y + 30);
    doc.setFont('helvetica', 'normal');
    doc.text(new Date(device.uploadTime).toLocaleDateString(), margin + 132, y + 30);

    y += 44;

    // Executive Scorecard Card
    const score = device.overallComplianceScore;
    const scoreColor = score >= 80 ? [16, 185, 129] : score >= 60 ? [245, 158, 11] : [239, 68, 68];

    doc.setFillColor(241, 245, 249); // slate-100
    doc.setDrawColor(203, 213, 225);
    doc.roundedRect(margin, y, pageWidth - margin * 2, 28, 2, 2, 'FD');

    doc.setFontSize(10);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(15, 23, 42);
    doc.text('Security Baseline Compliance Scorecard', margin + 4, y + 7);

    // Score Circle / Pill
    doc.setFillColor(scoreColor[0], scoreColor[1], scoreColor[2]);
    doc.roundedRect(margin + 4, y + 11, 28, 12, 1.5, 1.5, 'F');
    doc.setTextColor(255, 255, 255);
    doc.setFontSize(11);
    doc.setFont('helvetica', 'bold');
    doc.text(`${score}%`, margin + 11, y + 19.5);

    doc.setFontSize(8);
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(71, 85, 105);

    // Compute passed, failed, not-evaluable
    let totalP = 0;
    let totalF = 0;
    let totalN = 0;
    devEvals.forEach((ev) => {
      totalP += ev.passedCount;
      totalF += ev.failedCount;
      totalN += ev.notEvaluableCount;
    });

    doc.setFont('helvetica', 'bold');
    doc.text('Overall Status:', margin + 38, y + 15);
    doc.setFont('helvetica', 'normal');
    doc.text(device.status, margin + 63, y + 15);

    doc.setFont('helvetica', 'bold');
    doc.text('Passed Controls:', margin + 38, y + 21);
    doc.setFont('helvetica', 'normal');
    doc.text(`${totalP} controls`, margin + 63, y + 21);

    doc.setFont('helvetica', 'bold');
    doc.text('Failed Controls:', margin + 105, y + 15);
    doc.setFont('helvetica', 'normal');
    doc.text(`${totalF} controls`, margin + 132, y + 15);

    doc.setFont('helvetica', 'bold');
    doc.text('Frameworks Evaluated:', margin + 105, y + 21);
    doc.setFont('helvetica', 'normal');
    doc.text(`${devEvals.length} Standards (CIS, NIST, STIG, ISO)`, margin + 138, y + 21);

    y += 34;

    // Framework Summary Table
    checkPageBreak(30);
    doc.setFontSize(11);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(15, 23, 42);
    doc.text('Compliance Breakdown by Security Framework', margin, y);
    y += 4;

    // Framework Table Header
    doc.setFillColor(30, 41, 59); // slate-800
    doc.rect(margin, y, pageWidth - margin * 2, 7, 'F');
    doc.setTextColor(255, 255, 255);
    doc.setFontSize(8);
    doc.setFont('helvetica', 'bold');
    doc.text('Framework Name', margin + 3, y + 5);
    doc.text('Version', margin + 60, y + 5);
    doc.text('Score', margin + 95, y + 5);
    doc.text('Passed', margin + 115, y + 5);
    doc.text('Failed', margin + 135, y + 5);
    doc.text('Not Evaluable', margin + 155, y + 5);
    y += 7;

    doc.setFont('helvetica', 'normal');
    devEvals.forEach((ev, idx) => {
      checkPageBreak(8);
      doc.setFillColor(idx % 2 === 0 ? 255 : 248, idx % 2 === 0 ? 255 : 250, idx % 2 === 0 ? 255 : 252);
      doc.rect(margin, y, pageWidth - margin * 2, 6, 'F');
      doc.setTextColor(30, 41, 59);
      doc.setFontSize(8);
      doc.text(ev.frameworkName, margin + 3, y + 4.2);
      doc.text(ev.frameworkVersion, margin + 60, y + 4.2);
      doc.text(`${ev.complianceScore}%`, margin + 95, y + 4.2);
      doc.text(String(ev.passedCount), margin + 115, y + 4.2);
      doc.text(String(ev.failedCount), margin + 135, y + 4.2);
      doc.text(String(ev.notEvaluableCount), margin + 155, y + 4.2);
      y += 6;
    });

    y += 8;

    // Detailed Pass / Fail Evaluation Controls Table
    checkPageBreak(35);
    doc.setFontSize(11);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(15, 23, 42);
    doc.text('Detailed Security Controls Matrix', margin, y);
    y += 4;

    // Controls Table Header
    doc.setFillColor(30, 41, 59);
    doc.rect(margin, y, pageWidth - margin * 2, 7, 'F');
    doc.setTextColor(255, 255, 255);
    doc.setFontSize(8);
    doc.setFont('helvetica', 'bold');
    doc.text('Control ID & Title', margin + 3, y + 5);
    doc.text('Framework', margin + 65, y + 5);
    doc.text('Severity', margin + 95, y + 5);
    doc.text('Expected Value', margin + 120, y + 5);
    doc.text('Status', margin + 155, y + 5);
    y += 7;

    // Render controls across all frameworks
    devEvals.forEach((ev) => {
      ev.controlResults.forEach((ctrl, idx) => {
        checkPageBreak(8);
        doc.setFillColor(idx % 2 === 0 ? 255 : 248, idx % 2 === 0 ? 255 : 250, idx % 2 === 0 ? 255 : 252);
        doc.rect(margin, y, pageWidth - margin * 2, 6.5, 'F');

        doc.setFontSize(7.5);
        doc.setFont('helvetica', 'bold');
        doc.setTextColor(15, 23, 42);
        const titleShort = `${ctrl.controlId}: ${ctrl.title}`.substring(0, 36);
        doc.text(titleShort, margin + 3, y + 4.5);

        doc.setFont('helvetica', 'normal');
        doc.setTextColor(71, 85, 105);
        doc.text(ev.frameworkName.substring(0, 16), margin + 65, y + 4.5);

        // Severity
        doc.setFont('helvetica', 'bold');
        if (ctrl.severity === 'CRITICAL') doc.setTextColor(225, 29, 72);
        else if (ctrl.severity === 'HIGH') doc.setTextColor(234, 88, 12);
        else if (ctrl.severity === 'MEDIUM') doc.setTextColor(202, 138, 4);
        else doc.setTextColor(71, 85, 105);
        doc.text(ctrl.severity, margin + 95, y + 4.5);

        // Expected
        doc.setFont('helvetica', 'normal');
        doc.setTextColor(71, 85, 105);
        doc.text(String(ctrl.expectedValue).substring(0, 16), margin + 120, y + 4.5);

        // Status
        if (ctrl.status === 'PASS') {
          doc.setTextColor(16, 185, 129);
          doc.setFont('helvetica', 'bold');
          doc.text('PASS', margin + 155, y + 4.5);
        } else if (ctrl.status === 'FAIL') {
          doc.setTextColor(239, 68, 68);
          doc.setFont('helvetica', 'bold');
          doc.text('FAIL', margin + 155, y + 4.5);
        } else {
          doc.setTextColor(245, 158, 11);
          doc.setFont('helvetica', 'bold');
          doc.text('N/A', margin + 155, y + 4.5);
        }

        y += 6.5;
      });
    });

    y += 10;

    // Step-by-Step Vendor CLI Remediation Section
    checkPageBreak(40);
    doc.setFontSize(12);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(15, 23, 42);
    doc.text(`Step-by-Step CLI Remediation (${device.detectedVendor} Syntax)`, margin, y);
    y += 4;

    doc.setFontSize(8);
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(100, 116, 139);
    doc.text('Exact terminal CLI statements to fix identified non-compliant security controls on this device.', margin, y);
    y += 6;

    if (failedControls.length === 0) {
      doc.setFillColor(240, 253, 244); // emerald-50
      doc.setDrawColor(187, 247, 208);
      doc.roundedRect(margin, y, pageWidth - margin * 2, 16, 1.5, 1.5, 'FD');
      doc.setTextColor(21, 128, 61);
      doc.setFontSize(9);
      doc.setFont('helvetica', 'bold');
      doc.text('All controls compliant! No CLI remediation required for this network device.', margin + 4, y + 9);
      y += 20;
    } else {
      failedControls.forEach((ctrl, i) => {
        checkPageBreak(36);

        // Find matching tailored CLI command
        const remObj = cliRemediations.find((r) => r.controlId === ctrl.controlId);
        const cliText = remObj?.cliCommands || ctrl.remediation.replace(/\{vendor\}/g, device.detectedVendor);

        // Card container
        doc.setFillColor(254, 242, 242); // rose-50
        doc.setDrawColor(254, 202, 202); // rose-200
        doc.roundedRect(margin, y, pageWidth - margin * 2, 8, 1, 1, 'FD');

        doc.setFontSize(8.5);
        doc.setFont('helvetica', 'bold');
        doc.setTextColor(159, 18, 57);
        doc.text(`[FAIL - ${ctrl.severity}] Control ${ctrl.controlId}: ${ctrl.title}`, margin + 3, y + 5.5);
        y += 9;

        // Command code block box
        const lines = doc.splitTextToSize(cliText, pageWidth - margin * 2 - 8);
        const boxHeight = Math.max(14, lines.length * 3.5 + 4);
        checkPageBreak(boxHeight + 4);

        doc.setFillColor(15, 23, 42); // slate-900 (terminal box)
        doc.setDrawColor(51, 65, 85);
        doc.roundedRect(margin, y, pageWidth - margin * 2, boxHeight, 1, 1, 'F');

        doc.setTextColor(6, 182, 212); // cyan-400 font
        doc.setFont('courier', 'normal');
        doc.setFontSize(7.5);
        doc.text(lines, margin + 4, y + 4.5);

        y += boxHeight + 4;
      });
    }

    // Add page numbers and footers across all pages
    const totalPages = doc.getNumberOfPages();
    for (let p = 1; p <= totalPages; p++) {
      doc.setPage(p);
      doc.setDrawColor(226, 232, 240);
      doc.line(margin, pageHeight - 12, pageWidth - margin, pageHeight - 12);
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(7.5);
      doc.setTextColor(148, 163, 184);
      doc.text(`ZENTRA Network Security Compliance Audit | ${device.hostname || device.filename}`, margin, pageHeight - 7);
      doc.text(`Page ${p} of ${totalPages}`, pageWidth - margin - 20, pageHeight - 7);
    }

    const cleanName = (device.hostname || device.filename).replace(/[^a-zA-Z0-9_-]/g, '_');
    return { doc, filename: `${cleanName}-compliance-report.pdf` };
  };

  // Export single device PDF
  const handleExportSinglePdf = async (device: NetworkDevice) => {
    try {
      setGeneratingIds((prev) => ({ ...prev, [device.id]: true }));
      const { doc, filename } = await buildDevicePdf(device);
      doc.save(filename);
      showToast('PDF Export Complete', `Downloaded audit report for ${device.hostname || device.filename}.`, 'success');
    } catch (err: any) {
      showToast('PDF Export Error', err.message, 'error');
    } finally {
      setGeneratingIds((prev) => ({ ...prev, [device.id]: false }));
    }
  };

  // Export All as ZIP
  const handleExportAllZip = async () => {
    if (devices.length === 0) {
      showToast('No Devices Available', 'Ingest devices or load sample configs first.', 'error');
      return;
    }

    try {
      setIsBulkExporting(true);
      const zip = new JSZip();

      for (let i = 0; i < devices.length; i++) {
        const device = devices[i];
        setBulkProgress({
          current: i + 1,
          total: devices.length,
          hostname: device.hostname || device.filename,
        });

        const { doc, filename } = await buildDevicePdf(device);
        const pdfArrayBuffer = doc.output('arraybuffer');
        zip.file(filename, pdfArrayBuffer);
      }

      // Add a fleet-wide manifest
      const manifest = {
        generatedAt: new Date().toISOString(),
        totalDevices: devices.length,
        devices: devices.map((d) => ({
          hostname: d.hostname,
          vendor: d.detectedVendor,
          model: d.model,
          complianceScore: d.overallComplianceScore,
          status: d.status,
          filename: d.filename,
        })),
        engine: 'ZENTRA Vendor-Agnostic Network Configuration Compliance Platform',
      };
      zip.file('audit-manifest.json', JSON.stringify(manifest, null, 2));

      setBulkProgress({
        current: devices.length,
        total: devices.length,
        hostname: 'Packaging ZIP Archive...',
      });

      const zipBlob = await zip.generateAsync({ type: 'blob' });
      const url = URL.createObjectURL(zipBlob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `zentra-fleet-compliance-reports-${new Date().toISOString().split('T')[0]}.zip`;
      link.click();
      URL.revokeObjectURL(url);

      showToast(
        'Bulk ZIP Export Complete',
        `Successfully packaged ${devices.length} per-device compliance reports into ZIP.`,
        'success'
      );
    } catch (err: any) {
      showToast('ZIP Export Error', err.message, 'error');
    } finally {
      setIsBulkExporting(false);
      setBulkProgress(null);
    }
  };

  // Preview Modal
  const handleOpenPreview = async (device: NetworkDevice) => {
    setPreviewDevice(device);
    setLoadingPreview(true);

    try {
      // Find failed controls
      const devEvals = evaluations.filter((e) => e.deviceId === device.id);
      const failedControls: ControlEvaluationResult[] = [];
      devEvals.forEach((ev) => {
        ev.controlResults.forEach((c) => {
          if (c.status === 'FAIL' && !failedControls.some((fc) => fc.controlId === c.controlId)) {
            failedControls.push(c);
          }
        });
      });

      if (failedControls.length > 0) {
        const res = await apiService.getVendorCliRemediations({
          vendor: device.detectedVendor,
          model: device.model,
          hostname: device.hostname,
          controls: failedControls.map((fc) => ({
            controlId: fc.controlId,
            title: fc.title,
            field: fc.field,
            expectedValue: fc.expectedValue,
            actualValue: fc.actualValue,
            remediation: fc.remediation,
          })),
        });
        setPreviewRemediations(res.remediations);
      } else {
        setPreviewRemediations([]);
      }
    } catch (err: any) {
      console.warn('Preview error:', err);
    } finally {
      setLoadingPreview(false);
    }
  };

  // Filtered devices list
  const filteredDevices = useMemo(() => {
    return devices.filter((d) => {
      if (vendorFilter !== 'ALL' && !d.detectedVendor.toLowerCase().includes(vendorFilter.toLowerCase())) {
        return false;
      }
      if (search.trim()) {
        const q = search.toLowerCase().trim();
        const matchesHost = d.hostname?.toLowerCase().includes(q);
        const matchesFile = d.filename.toLowerCase().includes(q);
        const matchesVendor = d.detectedVendor.toLowerCase().includes(q);
        const matchesModel = d.model?.toLowerCase().includes(q);
        if (!matchesHost && !matchesFile && !matchesVendor && !matchesModel) return false;
      }
      return true;
    });
  }, [devices, vendorFilter, search]);

  const uniqueVendors = useMemo(() => {
    return Array.from(new Set(devices.map((d) => d.detectedVendor)));
  }, [devices]);

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <h1 className="text-2xl font-bold text-white tracking-tight flex items-center gap-2">
              <FileText className="w-6 h-6 text-cyan-400" />
              Per-Device PDF Audit Reports
            </h1>
            <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-cyan-500/10 text-cyan-400 border border-cyan-500/30">
              Vendor CLI Remediation
            </span>
          </div>
          <p className="text-sm text-slate-400 mt-1">
            Generate formal compliance reports per network device with hardware identification, multi-framework scorecards, and copy-pasteable CLI commands tailored to each vendor's syntax.
          </p>
        </div>

        <div className="flex items-center gap-2.5 flex-wrap">
          <button
            onClick={handleLoadSampleDevices}
            className="px-3.5 py-2 text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-lg flex items-center gap-1.5 transition-colors"
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            Load Sample Fleet (5 Vendors)
          </button>

          <button
            onClick={handleExportAllZip}
            disabled={isBulkExporting || devices.length === 0}
            className="px-4 py-2 text-xs font-semibold bg-cyan-600 hover:bg-cyan-500 text-white rounded-lg flex items-center gap-2 shadow-lg shadow-cyan-900/30 transition-all disabled:opacity-50"
          >
            <Archive className="w-4 h-4" />
            {isBulkExporting ? 'Packaging ZIP...' : `Export All as ZIP (${devices.length} Devices)`}
          </button>
        </div>
      </div>

      {/* Progress Overlay for Bulk ZIP Export */}
      {isBulkExporting && bulkProgress && (
        <Card className="p-4 bg-cyan-950/40 border-cyan-800 animate-pulse">
          <div className="flex items-center justify-between text-xs text-cyan-300 font-mono mb-2">
            <span className="flex items-center gap-2">
              <RotateCw className="w-4 h-4 animate-spin text-cyan-400" />
              Generating Report {bulkProgress.current} of {bulkProgress.total}: {bulkProgress.hostname}
            </span>
            <span>{Math.round((bulkProgress.current / bulkProgress.total) * 100)}%</span>
          </div>
          <div className="w-full bg-slate-900 h-2 rounded-full overflow-hidden">
            <div
              className="bg-cyan-500 h-full transition-all duration-300"
              style={{ width: `${(bulkProgress.current / bulkProgress.total) * 100}%` }}
            />
          </div>
        </Card>
      )}

      {/* Filter and Search Bar */}
      <Card className="p-4 bg-slate-900/60 border-slate-800">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="relative">
              <Search className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                placeholder="Search by hostname, model, or filename..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="bg-slate-950 border border-slate-800 text-slate-200 text-xs rounded-lg pl-8 pr-3 py-1.5 focus:outline-none focus:border-cyan-500 w-64 placeholder:text-slate-600"
              />
            </div>

            <select
              value={vendorFilter}
              onChange={(e) => setVendorFilter(e.target.value)}
              className="bg-slate-950 border border-slate-800 text-slate-300 text-xs rounded-lg px-3 py-1.5 focus:outline-none focus:border-cyan-500"
            >
              <option value="ALL">All Vendors ({uniqueVendors.length})</option>
              {uniqueVendors.map((v) => (
                <option key={v} value={v}>
                  {v}
                </option>
              ))}
            </select>
          </div>

          <div className="text-xs text-slate-400">
            Showing <span className="text-slate-200 font-mono font-bold">{filteredDevices.length}</span> of{' '}
            <span className="text-slate-200 font-mono">{devices.length}</span> devices ready for PDF export
          </div>
        </div>
      </Card>

      {/* Devices Grid for Report Generation */}
      {loading ? (
        <div className="py-20 text-center">
          <div className="w-8 h-8 border-2 border-cyan-500 border-t-transparent rounded-full animate-spin mx-auto mb-3" />
          <p className="text-xs font-mono text-cyan-400">LOADING DEVICE REPOSITORY...</p>
        </div>
      ) : filteredDevices.length === 0 ? (
        <Card className="p-12 text-center bg-slate-900/60 border-slate-800">
          <Server className="w-12 h-12 text-slate-600 mx-auto mb-3" />
          <h3 className="text-base font-medium text-slate-300">No Network Devices Found</h3>
          <p className="text-xs text-slate-500 max-w-md mx-auto mt-1 mb-4">
            Upload configuration files or load the 5 realistic multi-vendor sample configurations to generate per-device audit PDFs.
          </p>
          <button
            onClick={handleLoadSampleDevices}
            className="px-4 py-2 text-xs font-semibold bg-cyan-600 hover:bg-cyan-500 text-white rounded-lg inline-flex items-center gap-2"
          >
            <Sparkles className="w-3.5 h-3.5" />
            Load Sample Fleet Now
          </button>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredDevices.map((dev) => {
            const isGenerating = !!generatingIds[dev.id];
            const devEvals = evaluations.filter((e) => e.deviceId === dev.id);
            let failedCount = 0;
            devEvals.forEach((e) => {
              failedCount += e.failedCount;
            });

            return (
              <Card
                key={dev.id}
                className="bg-slate-900/90 border-slate-800 hover:border-slate-700 transition-all p-5 flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-start justify-between gap-2 mb-2">
                    <div>
                      <div className="flex items-center gap-2">
                        <Server className="w-4 h-4 text-cyan-400" />
                        <h3 className="font-bold text-slate-100 text-sm tracking-tight truncate max-w-[180px]">
                          {dev.hostname || dev.filename}
                        </h3>
                      </div>
                      <div className="text-[11px] text-slate-400 mt-0.5">
                        {dev.filename}
                      </div>
                    </div>

                    <span
                      className={`text-sm font-extrabold font-mono px-2 py-0.5 rounded ${
                        dev.overallComplianceScore >= 80
                          ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                          : dev.overallComplianceScore >= 60
                          ? 'bg-amber-950 text-amber-400 border border-amber-800'
                          : 'bg-rose-950 text-rose-400 border border-rose-800'
                      }`}
                    >
                      {dev.overallComplianceScore}%
                    </span>
                  </div>

                  {/* Metadata Chips */}
                  <div className="space-y-1.5 my-3 pt-2 border-t border-slate-800/60 text-xs">
                    <div className="flex items-center justify-between">
                      <span className="text-slate-500">Vendor / OS:</span>
                      <span className="text-slate-200 font-medium truncate max-w-[160px]">
                        {dev.detectedVendor}
                      </span>
                    </div>

                    <div className="flex items-center justify-between">
                      <span className="text-slate-500">Hardware Model:</span>
                      <span className="text-slate-300 font-mono text-[11px] truncate max-w-[160px]">
                        {dev.model || 'Enterprise Switch'}
                      </span>
                    </div>

                    <div className="flex items-center justify-between">
                      <span className="text-slate-500">Serial Number:</span>
                      <span className="text-slate-400 font-mono text-[11px]">
                        {dev.serialNumber || 'SN-UNKNOWN'}
                      </span>
                    </div>

                    <div className="flex items-center justify-between">
                      <span className="text-slate-500">Non-Compliant Gaps:</span>
                      <span className={`font-mono text-xs font-bold ${failedCount > 0 ? 'text-rose-400' : 'text-emerald-400'}`}>
                        {failedCount} failed controls
                      </span>
                    </div>
                  </div>

                  {/* Mini Framework Matrix */}
                  <div className="grid grid-cols-4 gap-1 py-2 text-center text-[10px] font-mono bg-slate-950 rounded border border-slate-800/80 mb-4">
                    {['cis', 'nist', 'disa-stig', 'iso-27001'].map((fwId) => {
                      const ev = devEvals.find((e) => e.frameworkId === fwId);
                      const sc = ev ? ev.complianceScore : dev.overallComplianceScore;
                      return (
                        <div key={fwId} className="p-1">
                          <div className="text-slate-500 uppercase">{fwId.split('-')[0]}</div>
                          <div className={`font-bold mt-0.5 ${sc >= 80 ? 'text-emerald-400' : sc >= 60 ? 'text-amber-400' : 'text-rose-400'}`}>
                            {sc}%
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* Actions */}
                <div className="flex items-center gap-2 pt-2 border-t border-slate-800">
                  <button
                    onClick={() => handleOpenPreview(dev)}
                    className="flex-1 py-1.5 px-2 text-xs font-medium text-slate-300 hover:text-white bg-slate-800/80 hover:bg-slate-700/80 border border-slate-700 rounded-lg flex items-center justify-center gap-1 transition-colors"
                  >
                    <Eye className="w-3.5 h-3.5 text-slate-400" />
                    Preview
                  </button>

                  <button
                    onClick={() => handleExportSinglePdf(dev)}
                    disabled={isGenerating}
                    className="flex-1 py-1.5 px-2 text-xs font-semibold text-cyan-300 bg-cyan-950/60 hover:bg-cyan-900/60 border border-cyan-800 rounded-lg flex items-center justify-center gap-1.5 transition-colors disabled:opacity-50"
                  >
                    <Download className={`w-3.5 h-3.5 ${isGenerating ? 'animate-spin' : ''}`} />
                    {isGenerating ? 'Generating...' : 'Export PDF'}
                  </button>
                </div>
              </Card>
            );
          })}
        </div>
      )}

      {/* Preview Modal for Device Scorecard & CLI */}
      {previewDevice && (
        <Modal
          isOpen={!!previewDevice}
          onClose={() => setPreviewDevice(null)}
          title={`Audit Certificate Preview: ${previewDevice.hostname || previewDevice.filename}`}
          maxWidth="3xl"
        >
          <div className="space-y-4">
            <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
              <div>
                <span className="text-slate-500 block">Vendor</span>
                <span className="font-semibold text-slate-200">{previewDevice.detectedVendor}</span>
              </div>
              <div>
                <span className="text-slate-500 block">Model</span>
                <span className="font-mono text-cyan-300">{previewDevice.model || 'Standard'}</span>
              </div>
              <div>
                <span className="text-slate-500 block">Serial Number</span>
                <span className="font-mono text-slate-300">{previewDevice.serialNumber || 'SN-UNKNOWN'}</span>
              </div>
              <div>
                <span className="text-slate-500 block">Compliance Score</span>
                <span className="font-mono font-bold text-base text-emerald-400">{previewDevice.overallComplianceScore}%</span>
              </div>
            </div>

            {/* CLI Remediations Section */}
            <div>
              <h4 className="text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2 flex items-center gap-2">
                <Terminal className="w-4 h-4 text-cyan-400" />
                Tailored CLI Remediation Commands ({previewDevice.detectedVendor} Syntax)
              </h4>

              {loadingPreview ? (
                <div className="py-8 text-center text-xs text-slate-400 flex items-center justify-center gap-2">
                  <RotateCw className="w-4 h-4 animate-spin text-cyan-400" />
                  Generating syntax-accurate CLI scripts with Gemini AI...
                </div>
              ) : previewRemediations.length === 0 ? (
                <div className="p-4 bg-emerald-950/20 border border-emerald-800/40 rounded-lg text-xs text-emerald-400 flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4" />
                  Device is 100% compliant across tested controls. No remediation necessary.
                </div>
              ) : (
                <div className="space-y-3 max-h-80 overflow-y-auto pr-1">
                  {previewRemediations.map((rem) => (
                    <div key={rem.controlId} className="p-3 bg-slate-950 border border-slate-800 rounded-lg text-xs space-y-1.5">
                      <div className="flex items-center justify-between text-[11px]">
                        <span className="font-mono font-bold text-rose-400">{rem.controlId}</span>
                        <span className="text-slate-500 font-mono">Field: {rem.field}</span>
                      </div>
                      <pre className="p-2.5 bg-slate-900 text-cyan-300 font-mono text-[11px] rounded border border-slate-800 overflow-x-auto selection:bg-cyan-500/40 whitespace-pre-wrap">
                        {rem.cliCommands}
                      </pre>
                    </div>
                  ))}
                </div>
              )}
            </div>

            <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-800">
              <button
                type="button"
                onClick={() => setPreviewDevice(null)}
                className="px-4 py-2 text-xs font-medium text-slate-400 hover:text-slate-200"
              >
                Close Preview
              </button>
              <button
                type="button"
                onClick={() => {
                  handleExportSinglePdf(previewDevice);
                  setPreviewDevice(null);
                }}
                className="px-4 py-2 text-xs font-semibold bg-cyan-600 hover:bg-cyan-500 text-white rounded-lg flex items-center gap-1.5"
              >
                <Download className="w-3.5 h-3.5" />
                Download PDF Certificate
              </button>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
}
