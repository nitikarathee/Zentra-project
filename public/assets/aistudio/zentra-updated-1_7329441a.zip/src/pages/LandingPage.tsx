import React, { useEffect, useRef, useState } from 'react';
import {
  ArrowRight,
  Layers,
  GraduationCap,
  FileCheck2,
  FileText,
  Boxes,
  ShieldCheck,
  Upload,
  Cpu,
  Wrench,
  CornerDownLeft,
  AlertTriangle,
  Network,
} from 'lucide-react';
import { Logo } from '../components/common/Logo';

/**
 * OPTIONAL: paste a direct .mp4 / .webm URL here (e.g. a network-security stock
 * clip) and it plays behind the hero. Leave empty to use the animated
 * network-topology background below (works offline, no copyright issues).
 */
const HERO_VIDEO_URL = '';

interface LandingPageProps {
  onEnter: () => void;
}

function NetworkCanvas() {
  const ref = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = ref.current!;
    const ctx = canvas.getContext('2d')!;
    let raf = 0;
    let w = 0;
    let h = 0;
    type Node = { x: number; y: number; vx: number; vy: number; r: number; hot: boolean };
    let nodes: Node[] = [];
    const packets: { a: number; b: number; t: number }[] = [];

    const resize = () => {
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      w = canvas.clientWidth;
      h = canvas.clientHeight;
      canvas.width = w * dpr;
      canvas.height = h * dpr;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      const count = Math.max(24, Math.min(70, Math.floor((w * h) / 22000)));
      nodes = Array.from({ length: count }, () => ({
        x: Math.random() * w,
        y: Math.random() * h,
        vx: (Math.random() - 0.5) * 0.25,
        vy: (Math.random() - 0.5) * 0.25,
        r: 1.5 + Math.random() * 2.2,
        hot: Math.random() < 0.12,
      }));
    };
    resize();
    window.addEventListener('resize', resize);

    const draw = () => {
      ctx.clearRect(0, 0, w, h);
      const maxD = Math.min(170, w / 4);

      for (const n of nodes) {
        n.x += n.vx;
        n.y += n.vy;
        if (n.x < 0 || n.x > w) n.vx *= -1;
        if (n.y < 0 || n.y > h) n.vy *= -1;
      }

      for (let i = 0; i < nodes.length; i++) {
        for (let j = i + 1; j < nodes.length; j++) {
          const dx = nodes[i].x - nodes[j].x;
          const dy = nodes[i].y - nodes[j].y;
          const d = Math.hypot(dx, dy);
          if (d < maxD) {
            ctx.strokeStyle = `rgba(34,211,238,${(1 - d / maxD) * 0.22})`;
            ctx.lineWidth = 1;
            ctx.beginPath();
            ctx.moveTo(nodes[i].x, nodes[i].y);
            ctx.lineTo(nodes[j].x, nodes[j].y);
            ctx.stroke();
            if (Math.random() < 0.0009 && packets.length < 18) packets.push({ a: i, b: j, t: 0 });
          }
        }
      }

      for (let k = packets.length - 1; k >= 0; k--) {
        const p = packets[k];
        p.t += 0.02;
        if (p.t >= 1) {
          packets.splice(k, 1);
          continue;
        }
        const A = nodes[p.a];
        const B = nodes[p.b];
        ctx.fillStyle = 'rgba(52,211,153,0.95)';
        ctx.beginPath();
        ctx.arc(A.x + (B.x - A.x) * p.t, A.y + (B.y - A.y) * p.t, 2.2, 0, Math.PI * 2);
        ctx.fill();
      }

      for (const n of nodes) {
        ctx.fillStyle = n.hot ? 'rgba(251,113,133,0.9)' : 'rgba(103,232,249,0.85)';
        ctx.beginPath();
        ctx.arc(n.x, n.y, n.r, 0, Math.PI * 2);
        ctx.fill();
        if (n.hot) {
          ctx.strokeStyle = 'rgba(251,113,133,0.25)';
          ctx.beginPath();
          ctx.arc(n.x, n.y, n.r + 5 + Math.sin(Date.now() / 300) * 2, 0, Math.PI * 2);
          ctx.stroke();
        }
      }
      raf = requestAnimationFrame(draw);
    };
    draw();

    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener('resize', resize);
    };
  }, []);

  return <canvas ref={ref} className="absolute inset-0 w-full h-full" />;
}

const VENDORS = [
  'Cisco', 'Palo Alto', 'Fortinet', 'Juniper', 'Arista', 'Check Point', 'HPE Aruba', 'SONiC',
  'Cumulus', 'MikroTik', 'Huawei', 'Sophos', 'SonicWall', 'AWS Security Groups', 'Azure NSG',
  'GCP Firewall', 'Zscaler', 'Extreme', 'Ubiquiti', 'NVIDIA / Mellanox', 'Nokia', 'Dell', 'VyOS',
];

const STEPS = [
  { icon: Upload, title: '1. Ingest', text: 'Drop one config or a whole fleet. Any vendor, any OS version, single or bulk upload.' },
  { icon: Layers, title: '2. Normalize', text: 'Raw CLI is mapped into a vendor-neutral Security Baseline Model (JSON schema).' },
  { icon: FileCheck2, title: '3. Evaluate', text: 'Checked against CIS, NIST SP 800-53, DISA STIG and ISO 27001 with Pass/Fail and severity.' },
  { icon: Wrench, title: '4. Remediate', text: 'Device-specific, step-by-step CLI fix sequences, exported in one PDF per device.' },
];

const FEATURES = [
  { icon: Upload, title: 'Unified Ingestion Engine', text: 'Upload single or bulk config files from firewalls, routers, switches, SASE and cloud-native rules in one dashboard.' },
  { icon: GraduationCap, title: 'AI Training Module', text: 'Unknown syntax? The raw lines are shown to the admin, who maps each one to a security category with a low-code UI. Rules hot-reload with zero redeploy.' },
  { icon: ShieldCheck, title: 'Multi-Framework Engine', text: 'Pick CIS, NIST, STIG or ISO. The same normalized model is evaluated against whichever benchmark you choose.' },
  { icon: FileText, title: 'Actionable PDF Reports', text: 'Per-device report: serial and hardware details, findings with risk severity, and exact CLI remediation steps.' },
  { icon: Boxes, title: 'Vendor-Agnostic by Design', text: 'New vendors, standards and OS versions are added as data packs, not code changes.' },
  { icon: Cpu, title: 'Gemini-Powered Parsing', text: 'Pattern recognition and NLP interpret configuration structures the system has never been trained on.' },
];

const STATS = [
  { v: '4', l: 'Frameworks' },
  { v: '20+', l: 'Vendor families' },
  { v: '0', l: 'Redeploys to add a vendor' },
  { v: '1', l: 'PDF per device' },
];

export function LandingPage({ onEnter }: LandingPageProps) {
  const [videoOk, setVideoOk] = useState(!!HERO_VIDEO_URL);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Enter') {
        e.preventDefault();
        onEnter();
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [onEnter]);

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 overflow-x-hidden">
      {/* ---------- HERO ---------- */}
      <section className="relative min-h-screen flex flex-col overflow-hidden">
        {videoOk && (
          <video
            className="absolute inset-0 w-full h-full object-cover opacity-40"
            src={HERO_VIDEO_URL}
            autoPlay
            muted
            loop
            playsInline
            onError={() => setVideoOk(false)}
          />
        )}
        {!videoOk && <NetworkCanvas />}
        <div className="absolute inset-0 bg-gradient-to-b from-slate-950/60 via-slate-950/40 to-slate-950" />
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,rgba(6,182,212,0.12),transparent_60%)]" />

        <header className="relative z-10 flex items-center justify-between px-5 sm:px-8 h-16">
          <Logo size="md" />
          <span className="hidden sm:inline-flex items-center gap-2 text-[11px] font-mono text-slate-400 border border-slate-800 rounded-full px-3 py-1 bg-slate-900/60">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
            Avinya Hackathon Build
          </span>
        </header>

        <div className="relative z-10 flex-1 flex flex-col items-center justify-center text-center px-5 sm:px-8 pb-10">
          <div className="inline-flex items-center gap-2 text-[11px] font-mono uppercase tracking-widest text-cyan-300 border border-cyan-500/30 bg-cyan-500/10 rounded-full px-3 py-1 mb-6">
            <Network className="w-3.5 h-3.5" />
            AI-augmented · Vendor-agnostic · Zero redeploy
          </div>

          <h1 className="font-extrabold tracking-tight leading-[1.05] text-4xl sm:text-6xl lg:text-7xl max-w-4xl">
            One engine to audit{' '}
            <span className="bg-gradient-to-r from-cyan-300 via-sky-400 to-emerald-300 bg-clip-text text-transparent">
              every network device
            </span>
          </h1>

          <p className="mt-6 max-w-2xl text-slate-300 text-sm sm:text-lg leading-relaxed">
            ZENTRA reads configuration files from any vendor, normalizes them into a single security
            baseline, scores them against CIS, NIST, STIG and ISO, and writes the exact CLI commands
            to fix what fails. When it meets a syntax it has never seen, you teach it in a few clicks.
          </p>

          <button
            onClick={onEnter}
            className="group mt-10 inline-flex items-center gap-3 px-7 py-3.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 font-semibold text-white shadow-[0_0_40px_rgba(6,182,212,0.35)] transition"
          >
            Launch ZENTRA
            <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
          </button>

          <div className="mt-5 flex items-center gap-2 text-xs font-mono text-slate-400">
            <span>or press</span>
            <kbd className="inline-flex items-center gap-1 px-2 py-1 rounded border border-slate-700 bg-slate-900 text-slate-200">
              <CornerDownLeft className="w-3 h-3" /> Enter
            </kbd>
            <span className="zt-blink text-cyan-400">_</span>
          </div>

          <div className="mt-12 grid grid-cols-2 sm:grid-cols-4 gap-3 sm:gap-4 w-full max-w-3xl">
            {STATS.map((s) => (
              <div key={s.l} className="rounded-xl border border-slate-800 bg-slate-900/60 backdrop-blur px-4 py-3">
                <div className="text-2xl sm:text-3xl font-extrabold text-cyan-300">{s.v}</div>
                <div className="text-[11px] text-slate-400 mt-0.5">{s.l}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ---------- PROBLEM ---------- */}
      <section className="px-5 sm:px-8 py-16 sm:py-24 max-w-6xl mx-auto">
        <div className="grid lg:grid-cols-2 gap-10 items-center">
          <div>
            <div className="inline-flex items-center gap-2 text-[11px] font-mono uppercase tracking-widest text-rose-300 mb-4">
              <AlertTriangle className="w-3.5 h-3.5" /> The core challenge
            </div>
            <h2 className="text-2xl sm:text-4xl font-bold leading-tight">
              Misconfiguration is the most common way networks get breached
            </h2>
            <p className="mt-5 text-slate-300 leading-relaxed">
              Firewalls, switches and routers guard the data, yet each vendor speaks its own CLI.
              A secure password setting on Cisco IOS looks nothing like the same setting on a Juniper
              SRX. Teams today choose between slow manual checklists and expensive, vendor-locked suites.
            </p>
            <ul className="mt-6 space-y-3 text-sm text-slate-300">
              <li className="flex gap-3"><span className="text-rose-400 font-mono">01</span> Syntactic diversity: proprietary CLI, hierarchies and OS versions.</li>
              <li className="flex gap-3"><span className="text-rose-400 font-mono">02</span> Static parsers break on White Box (SONiC), cloud security groups and new hardware.</li>
              <li className="flex gap-3"><span className="text-rose-400 font-mono">03</span> No single source of truth for compliance across a hybrid estate.</li>
            </ul>
          </div>

          {/* Fake before/after terminal */}
          <div className="rounded-2xl border border-slate-800 bg-slate-900/70 overflow-hidden font-mono text-[11px] sm:text-xs shadow-2xl">
            <div className="flex items-center gap-1.5 px-4 py-2.5 border-b border-slate-800 bg-slate-950/60">
              <span className="w-2.5 h-2.5 rounded-full bg-rose-500/80" />
              <span className="w-2.5 h-2.5 rounded-full bg-amber-500/80" />
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500/80" />
              <span className="ml-3 text-slate-500">core-sw01.cfg</span>
            </div>
            <div className="p-4 space-y-1 overflow-x-auto whitespace-pre">
              <div className="text-slate-500">! raw vendor config</div>
              <div className="text-slate-300">line vty 0 4</div>
              <div className="text-rose-300">  transport input telnet ssh</div>
              <div className="text-slate-300">ip http server</div>
              <div className="text-slate-300">snmp-server community public RO</div>
              <div className="pt-2 text-cyan-400">{'→ normalized'}</div>
              <div className="text-emerald-300">{'{ "telnet_enabled": true, "http_server": true,'}</div>
              <div className="text-emerald-300">{'  "snmp_v2_default_community": true }'}</div>
              <div className="pt-2 text-amber-300">{'✗ CIS 1.2.1 Disable Telnet      HIGH'}</div>
              <div className="text-amber-300">{'✗ NIST AC-17 Remote Access     HIGH'}</div>
              <div className="text-sky-300">{'⚡ fix: line vty 0 4 → transport input ssh'}</div>
            </div>
          </div>
        </div>
      </section>

      {/* ---------- HOW IT WORKS ---------- */}
      <section className="px-5 sm:px-8 py-16 bg-slate-900/30 border-y border-slate-800/70">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-2xl sm:text-4xl font-bold text-center">From raw config to fixed device in four steps</h2>
          <div className="mt-10 grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {STEPS.map(({ icon: Icon, title, text }) => (
              <div key={title} className="rounded-2xl border border-slate-800 bg-slate-950/70 p-5 hover:border-cyan-500/40 transition">
                <div className="w-10 h-10 rounded-lg bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-300 mb-4">
                  <Icon className="w-5 h-5" />
                </div>
                <h3 className="font-semibold">{title}</h3>
                <p className="mt-2 text-sm text-slate-400 leading-relaxed">{text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ---------- FEATURES ---------- */}
      <section className="px-5 sm:px-8 py-16 sm:py-24 max-w-6xl mx-auto">
        <h2 className="text-2xl sm:text-4xl font-bold text-center">Everything the problem statement asks for</h2>
        <div className="mt-10 grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {FEATURES.map(({ icon: Icon, title, text }) => (
            <div key={title} className="rounded-2xl border border-slate-800 bg-slate-900/50 p-6 hover:bg-slate-900 hover:border-slate-700 transition">
              <Icon className="w-6 h-6 text-emerald-300" />
              <h3 className="mt-4 font-semibold">{title}</h3>
              <p className="mt-2 text-sm text-slate-400 leading-relaxed">{text}</p>
            </div>
          ))}
        </div>
      </section>

      {/* ---------- VENDOR MARQUEE ---------- */}
      <section className="py-10 border-y border-slate-800/70 overflow-hidden">
        <p className="text-center text-[11px] font-mono uppercase tracking-widest text-slate-500 mb-5">
          Built to parse any vendor, including ones it has never seen
        </p>
        <div className="flex w-max zt-marquee gap-3 pr-3">
          {[...VENDORS, ...VENDORS].map((v, i) => (
            <span key={i} className="px-4 py-2 rounded-full border border-slate-800 bg-slate-900/60 text-sm text-slate-300 whitespace-nowrap">
              {v}
            </span>
          ))}
        </div>
      </section>

      {/* ---------- FINAL CTA ---------- */}
      <section className="px-5 sm:px-8 py-20 text-center">
        <h2 className="text-2xl sm:text-4xl font-bold">Ready to see it work?</h2>
        <p className="mt-3 text-slate-400">Log in with the demo accounts and try the training loop on an unknown vendor.</p>
        <button
          onClick={onEnter}
          className="group mt-8 inline-flex items-center gap-3 px-7 py-3.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 font-semibold shadow-[0_0_40px_rgba(6,182,212,0.3)] transition"
        >
          Enter the platform
          <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
        </button>
        <div className="mt-4 text-xs font-mono text-slate-500">Press Enter</div>
      </section>
    </div>
  );
}
